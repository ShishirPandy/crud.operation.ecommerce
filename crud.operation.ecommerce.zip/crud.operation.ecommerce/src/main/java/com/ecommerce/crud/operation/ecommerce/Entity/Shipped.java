package com.ecommerce.crud.operation.ecommerce.Entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table
@Getter
@Setter
public class Shipped {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
     private String cart_status="Not_shipped";
     private int total_price;
     private String email;
     private String address;



}
